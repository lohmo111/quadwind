"""Конфиги: базовый + метод + оверлеи вариантов; переопределения пространства условий; val варианта."""
import numpy as np
import pandas as pd
import pytest
import yaml
from pathlib import Path
from types import SimpleNamespace

from quadwind.conditions import TRAIN_SPACE, U, make_suite, override_space
from quadwind.env import EnvConfig
from quadwind.training import ValidationCallback, _schedule, build_space, load_config, load_model, validation_metrics
from scripts.run_series import finished_run


def test_release_recipe_matches_shipped_checkpoints():
    recipe = load_config("configs/rppo_hover.yaml")
    for seed in range(3):
        folder = Path("runs/e7/rppo__pi__safe__att__asym__hp_epochs5__hp_lstm128") / f"seed_{seed}"
        saved = yaml.safe_load((folder / "config.yaml").read_text(encoding="utf-8"))
        for key in ("name", "variants"):
            saved.pop(key)
        assert saved == {k: v for k, v in recipe.items() if k != "name"}


def test_normalized_checkpoint_requires_statistics(tmp_path):
    (tmp_path / "config.yaml").write_text("algo: rppo\nnormalize: {obs: true}\n", encoding="utf-8")
    with pytest.raises(FileNotFoundError, match="best_obs_norm"):
        load_model(tmp_path)


def test_unnormalized_checkpoint_ignores_old_statistics(tmp_path, monkeypatch):
    (tmp_path / "config.yaml").write_text("algo: ppo\nnormalize: {obs: false}\n", encoding="utf-8")
    (tmp_path / "best_obs_norm.npz").touch()
    monkeypatch.setattr("quadwind.training.PPO.load", lambda *args, **kwargs: object())
    _, normalizer, _ = load_model(tmp_path)
    assert normalizer is None


def test_validation_keeps_every_episode_in_score(monkeypatch):
    cfg = EnvConfig(max_dist=4.0)
    monkeypatch.setattr("quadwind.training.rollout", lambda *args: object())
    def short_flights(rollout, max_dist):
        assert max_dist == cfg.max_dist
        # Crash at 4 m; the other flight survived but ended before settling.
        return pd.DataFrame({"rmse_capped": [max_dist, np.nan]})
    monkeypatch.setattr("quadwind.training.episode_metrics", short_flights)
    with pytest.raises(ValueError, match="RMSE"):
        validation_metrics(SimpleNamespace(policy=None), None, cfg, [], 24)


def test_last_sb3_validation_uses_updated_weights(tmp_path, monkeypatch):
    callback = ValidationCallback(EnvConfig(), tmp_path, eval_freq=8, n=1)
    callback.model = SimpleNamespace(_total_timesteps=16)
    evaluations = []
    monkeypatch.setattr(callback, "_run", lambda: evaluations.append(callback.num_timesteps))
    for step in range(1, 17):
        callback.num_timesteps = step
        callback.locals.update(n_steps=(step - 1) % 4, n_rollout_steps=4)
        callback._on_step()
    assert evaluations == [8]
    callback._on_training_end()
    assert evaluations == [8, 16]


def test_series_recognizes_completed_legacy_run_and_checks_trainer():
    folder = Path("runs/e7/rppo__pi__safe__att__asym__hp_epochs5__hp_lstm128/seed_0")
    assert finished_run(folder, "sb3")
    with pytest.raises(ValueError, match="another --exp"):
        finished_run(folder, "native")


def test_linear_learning_rate_reaches_zero_on_rollout_overshoot():
    lr = _schedule(0.0003, "linear")
    assert lr(1) == 0.0003 and lr(-0.002) == 0


def test_overlay_merges_and_names_run():
    cfg = load_config("configs/rppo.yaml", ["configs/e7/v4_all.yaml"])
    assert cfg["name"] == "rppo__v4_all" and cfg["algo"] == "rppo"
    assert cfg["env"]["sigma_near"] == 0.05 and cfg["algo_kwargs"]["n_steps"] == 512
    space = build_space(cfg)
    assert space.jump_rate.bounds(1.0) == (0.0, 0.0) and space.noise_scale.bounds(1.0) == (1.0, 2.5)
    assert space.noise_scale.bounds(0.0) == (0.5, 0.5)            # curriculum задан явно
    assert space.slow_tau.bounds(1.0) == (10.0, 20.0)
    assert space.mass_ratio == TRAIN_SPACE.mass_ratio              # не тронутое — как в train
    assert load_config("configs/rppo.yaml")["name"] == "rppo"


def test_override_keeps_curriculum_and_rejects_unknown_keys():
    space = override_space(TRAIN_SPACE, {"wind_speed": [0.0, 5.0], "act_delay": [0, 2], "turb_type": "dryden"})
    assert space.wind_speed.bounds(0.0) == (0.0, 0.0) and space.wind_speed.bounds(1.0) == (0.0, 5.0)
    assert space.act_delay.bounds(1.0) == (0, 2) and space.turb_type == "dryden"
    with pytest.raises(AttributeError):
        override_space(TRAIN_SPACE, {"no_such_param": 1})


def test_variant_val_suite_uses_same_seeds_other_distribution():
    space = override_space(TRAIN_SPACE, {"noise_scale": [2.0, 2.0]})
    base, variant = make_suite("val", 8), make_suite("val", 8, space=space)
    assert [c.seed for c in base] == [c.seed for c in variant]
    assert all(c.noise_scale == 2.0 for c in variant) and not all(c.noise_scale == 2.0 for c in base)
    assert np.isclose(U(1, 1).sample(np.random.default_rng(0)), 1.0)
